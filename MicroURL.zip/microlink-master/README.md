# Microlink

A simple url-shortner made with 🐍 and lag 🙂

Try it out at [http://nikka-ja.herokuapp.com/](http://nikka-ja.herokuapp.com/)

## License

This project is licensed under the WTFPL (Do What the Fuck You Want To Public License) License - [WTFPL License](https://en.wikipedia.org/wiki/WTFPL)

